[HP, L] = lutinfo;
 LUT = lut;
 plotlut(HP, L, LUT);